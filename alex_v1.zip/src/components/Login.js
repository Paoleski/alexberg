import React from 'react'
import '../styles/login.css'
import SignUp from './SignUp'

const Login = () => {
    return (
        <div className="login">
            <SignUp/>
        </div>
    )
}

export default Login
